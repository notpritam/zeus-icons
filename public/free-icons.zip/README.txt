Free Icons export

6025 canonical Stroke Rounded SVGs from @hugeicons/core-free-icons 4.3.5.
Original artwork: Hugeicons, MIT license included.
The website lists 6035 entries; manifest.json records all source and package aliases.
Four website alias pairs have confirmed design conflicts and five pairs have unverified raster differences; see upstreamAliasReview entries in manifest.json. The exported SVGs match the installed package, not every distinct website preview.
SVGs use a 24 x 24 viewBox and preserve official attributes, including default stroke widths.
